package dev.mvc.shipping;

public class Product_MemberVO {

  /** ��ǰ��ȣ */
  private int pr_no;
  /** �Ǹ�ȸ����ȣ */
  private int pr_mem_no;
  /** �Ǹ��� ID */
  private String pr_mem_id;
  /** �Ǹ��� ���� */
  private String pr_mem_job;
  /** �Ǹ�ȸ�� �Ű�����Ƚ�� */
  private int pr_mem_acc;
  /** �Ǹ��� �̸� */
  private String pr_mem_name;
  /** �Ǹ��� �޴��� */
  private String pr_mem_tel;
  /** �Ǹ��� ���� */
  private String pr_mem_mail;
  /** �Ǹ��� ������ȣ */
  private String pr_mem_zipcode;
  /** �Ǹ��� �ּ�1 */
  private String pr_mem_addr1;
  /** �Ǹ��� �ּ�2 */
  private String pr_mem_addr2;

  public int getPr_no() {
    return pr_no;
  }

  public void setPr_no(int pr_no) {
    this.pr_no = pr_no;
  }

  public int getPr_mem_no() {
    return pr_mem_no;
  }

  public void setPr_mem_no(int pr_mem_no) {
    this.pr_mem_no = pr_mem_no;
  }

  public String getPr_mem_id() {
    return pr_mem_id;
  }

  public void setPr_mem_id(String pr_mem_id) {
    this.pr_mem_id = pr_mem_id;
  }

  public String getPr_mem_job() {
    return pr_mem_job;
  }

  public void setPr_mem_job(String pr_mem_job) {
    this.pr_mem_job = pr_mem_job;
  }

  public int getPr_mem_acc() {
    return pr_mem_acc;
  }

  public void setPr_mem_acc(int pr_mem_acc) {
    this.pr_mem_acc = pr_mem_acc;
  }

  public String getPr_mem_name() {
    return pr_mem_name;
  }

  public void setPr_mem_name(String pr_mem_name) {
    this.pr_mem_name = pr_mem_name;
  }

  public String getPr_mem_tel() {
    return pr_mem_tel;
  }

  public void setPr_mem_tel(String pr_mem_tel) {
    this.pr_mem_tel = pr_mem_tel;
  }

  public String getPr_mem_mail() {
    return pr_mem_mail;
  }

  public void setPr_mem_mail(String pr_mem_mail) {
    this.pr_mem_mail = pr_mem_mail;
  }

  public String getPr_mem_zipcode() {
    return pr_mem_zipcode;
  }

  public void setPr_mem_zipcode(String pr_mem_zipcode) {
    this.pr_mem_zipcode = pr_mem_zipcode;
  }

  public String getPr_mem_addr1() {
    return pr_mem_addr1;
  }

  public void setPr_mem_addr1(String pr_mem_addr1) {
    this.pr_mem_addr1 = pr_mem_addr1;
  }

  public String getPr_mem_addr2() {
    return pr_mem_addr2;
  }

  public void setPr_mem_addr2(String pr_mem_addr2) {
    this.pr_mem_addr2 = pr_mem_addr2;
  }

}
