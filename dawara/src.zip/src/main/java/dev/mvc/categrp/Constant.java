package dev.mvc.categrp;

public class Constant {
  public static final String CLASSIFICATION1 = "Blog";
  public static final String CLASSIFICATION2 = "Gallery";
  public static final String CLASSIFICATION3 = "Product";
  public static final String CLASSIFICATION9 = "��Ÿ";
}
