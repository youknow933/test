package dev.mvc.deal;

public class DealWayVO {
  private int dway_no;
  private String dway;
  /**
   * @return the dway_no
   */
  public int getDway_no() {
    return dway_no;
  }
  /**
   * @param dway_no the dway_no to set
   */
  public void setDway_no(int dway_no) {
    this.dway_no = dway_no;
  }
  /**
   * @return the dway
   */
  public String getDway() {
    return dway;
  }
  /**
   * @param dway the dway to set
   */
  public void setDway(String dway) {
    this.dway = dway;
  }
  
  
}
