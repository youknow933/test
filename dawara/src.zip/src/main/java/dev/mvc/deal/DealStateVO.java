package dev.mvc.deal;

public class DealStateVO {
  private int dstate_no;
  private String dealstate;
  private String dstate_date;
  /**
   * @return the dstate_no
   */
  public int getDstate_no() {
    return dstate_no;
  }
  /**
   * @param dstate_no the dstate_no to set
   */
  public void setDstate_no(int dstate_no) {
    this.dstate_no = dstate_no;
  }
  /**
   * @return the dealstate
   */
  public String getDealstate() {
    return dealstate;
  }
  /**
   * @param dealstate the dealstate to set
   */
  public void setDealstate(String dealstate) {
    this.dealstate = dealstate;
  }
  /**
   * @return the dstate_date
   */
  public String getDstate_date() {
    return dstate_date;
  }
  /**
   * @param dstate_date the dstate_date to set
   */
  public void setDstate_date(String dstate_date) {
    this.dstate_date = dstate_date;
  }
  
  
}
