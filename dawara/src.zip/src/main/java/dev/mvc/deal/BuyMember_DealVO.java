package dev.mvc.deal;

public class BuyMember_DealVO {
  
  private int buy_no; // ���Ź�ȣ
  private int mem_no; //
  private int deal_no; //
  private String buy_rdate; // ���Ź�ȣ
  private String mem_name;
  private String mem_mail;
  private String d_state;
  private String d_way;
  private String d_check;
  private String d_date;
  
  public int getBuy_no() {
    return buy_no;
  }
  
  public void setBuy_no(int buy_no) {
    this.buy_no = buy_no;
  }
  
  public int getMem_no() {
    return mem_no;
  }
  
  public void setMem_no(int mem_no) {
    this.mem_no = mem_no;
  }
  
  public int getDeal_no() {
    return deal_no;
  }
  
  public void setDeal_no(int deal_no) {
    this.deal_no = deal_no;
  }
  
  public String getBuy_rdate() {
    return buy_rdate;
  }
  
  public void setBuy_rdate(String buy_rdate) {
    this.buy_rdate = buy_rdate;
  }
  
  public String getMem_name() {
    return mem_name;
  }
  
  public void setMem_name(String mem_name) {
    this.mem_name = mem_name;
  }
  
  public String getMem_mail() {
    return mem_mail;
  }
  
  public void setMem_mail(String mem_mail) {
    this.mem_mail = mem_mail;
  }
  
  public String getD_state() {
    return d_state;
  }
  
  public void setD_state(String d_state) {
    this.d_state = d_state;
  }
  
  public String getD_way() {
    return d_way;
  }
  
  public void setD_way(String d_way) {
    this.d_way = d_way;
  }
  
  public String getD_check() {
    return d_check;
  }
  
  public void setD_check(String d_check) {
    this.d_check = d_check;
  }
  
  public String getD_date() {
    return d_date;
  }
  
  public void setD_date(String d_date) {
    this.d_date = d_date;
  }
  
}
