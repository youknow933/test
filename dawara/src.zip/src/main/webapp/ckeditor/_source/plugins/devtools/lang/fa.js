﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'devtools', 'fa',
{
	devTools :
	{
		title		: 'اطلاعات عنصر',
		dialogName	: 'نام پنجره محاوره‌ای',
		tabName		: 'نام برگه',
		elementId	: 'ID عنصر',
		elementType	: 'نوع عنصر'
	}
});
