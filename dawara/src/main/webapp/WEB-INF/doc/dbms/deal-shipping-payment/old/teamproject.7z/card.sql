/**********************************/
/* Table Name: ī����� */
/**********************************/
CREATE TABLE paycard(
    cardnumber                        NUMBER(16)     NULL ,
    mem_no                            NUMBER(6)     NOT NULL, 
    cardsort                          INTEGER(10)    NULL ,
    owner                             VARCHAR2(20)     NULL ,
    expires                           NUMBER(6)    NULL ,
    cmemo                             VARCHAR2(100)    NULL 
    
  PRIMARY KEY (cardnumber), 
  FOREIGN KEY (mem_no) REFERENCES p_member (mem_no)
);

COMMENT ON TABLE paycard is 'ī�����';
COMMENT ON COLUMN paycard.mem_no is 'ȸ����ȣ'; -- p_member ����
COMMENT ON COLUMN paycard.cardnumber is 'ī���ȣ';
COMMENT ON COLUMN paycard.cardsort is 'ī������';
COMMENT ON COLUMN paycard.owner is 'ī������';
COMMENT ON COLUMN paycard.expires is '���ᳯ¥';
COMMENT ON COLUMN paycard.memo is 'ī�忡 ���� �޸�';

