package dev.mvc.categrp;

import java.util.List;
  
public interface CategrpProcInter { // MyBatis�� �����ϴ� �޼ҵ� �ۼ�
  
  /**
   * <Xmp>
   *  ī�װ��� �׷� ���
   *  <insert id="create" parameterType="CategrpVO">
   * </Xmp>
   * @param categrpVO
   * @return ó���� ���ڵ� ����
   */
  public int create(CategrpVO categrpVO); 
  
  /**
   * ���(list)
   * <Xmp>
   *  <select id="list" resultType="CategrpVO">
   * </Xmp>
   * @return
   */
  public List<CategrpVO> list();
  
  /**
   * ��ȸ
   * <Xmp> 
   *  <select id="read" resultType="CategrpVO" parameterType="int">
   * </Xmp> 
   * @param categrpVO
   * @return
   */
  public CategrpVO read(int categrpno);
  
  /**
   * ���� ó��
   * <Xmp>
   *   <update id="update" parameterType="categrpVO">
   * </Xmp>
   * @param categrpVO
   * @return
   */
  public int update(CategrpVO categrpVO);
  
  /**
   * <Xmp>
   *  <delete id="delete" parameterType="int">
   * </Xmp>
   * @param categrpno
   * @return
   */
  public int delete(int categrpno);
  
  /**
   * <Xmp>
   *  <update id="update_seqno_up" parameterType="int">
   * </Xmp>
   * @return
   */
  public int update_seqno_up(int categrpno);
  
  /**
   * <Xmp>
   *  <update id="update_seqno_down" parameterType="int">
   * </Xmp>
   * @return
   */
  public int update_seqno_down(int categrpno);
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
      
      
      
      
  
}