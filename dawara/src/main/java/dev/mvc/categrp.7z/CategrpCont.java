package dev.mvc.categrp;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.category.CategoryProcInter;
import nation.web.tool.Messages;

@Controller // SpringFramework, ������� ��û�� ��Ʈ��. @Controller: Proc�� ȣ��
public class CategrpCont {
  @Autowired
  @Qualifier("dev.mvc.tool.Messages")
  private Messages messages = null;
  
  @Autowired // DI: ���� ����
  @Qualifier("dev.mvc.categrp.CategrpProc") // ��ü CategrpProc�� �������
  private CategrpProcInter categrpProc; // DAO�� �޸� �ʱ갪�� ������ �ڵ����� null�� ������.
  // categrpProc�� �Ҵ�Ǵ� Ŭ������? "dev.mvc.categrp.CategrpProc"(CategrpProc.java�� @Component�� �Ҵ�� Ŭ����)
  
  @Autowired
  @Qualifier("dev.mvc.category.CategoryProc")
  private CategoryProcInter categoryProc;
  
  public CategrpCont() {
    System.out.println("-> CategrpCont created."); // ���������� ȣ��ƴ��� Ȯ��
  }
  
  /** public ModelAndView �޼ҵ��() // �޼ҵ�� = Proc�� �ִ� �޼ҵ���� ��ġ��Ŵ. CategrpVO ������ �ڵ����� ���� */
  
  @RequestMapping(value="/categrp/create.do", method=RequestMethod.GET)
  public ModelAndView create(Locale locale) {
//    System.out.println("-> CategrpCont create() GET called.");
    ModelAndView mav = new ModelAndView();
    
//    if(categrpProc != null){
//      System.out.println("--> categrpProc: " + categrpProc.hashCode()); // create()�� ȣ������� �����
//      // hashCode(): ��ü �Ҵ��� �޾Ҵ��� Ȯ��(���� ������ ����)
//    }
    mav.setViewName("/categrp/create"); // /categrp/create.jsp
    
    return mav;
    // http://localhost:9090/ojt/categrp/create.do
    // http://localhost:9090/ojt/categrp/create.jsp -- ���� ȣ�� ����
  }
  
  // ****
  @RequestMapping(value="/categrp/create.do", method=RequestMethod.POST)
  public ModelAndView create(CategrpVO categrpVO, Locale locale) {
    ModelAndView mav = new ModelAndView();
    
//    if (categrpProc != null) {
//      System.out.println("--> categrpProc: " + categrpProc.hashCode());
//    }
    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>();
    
    if (categrpProc.create(categrpVO) == 1) {
      msgs.add(messages.getMessage("categrp.create.success", categrpVO.getName(), locale));
//      mav.setViewName("redirect:/categrp/list.do") 
      links.add("<button type='button' onclick=\"location.href='./list.do'\">" + messages.getMessage("categrp.button.list", categrpVO.getName(), locale) + "</button>");
    } else {
      msgs.add(messages.getMessage("categrp.create.fail", categrpVO.getName(), locale)); 
      msgs.add(messages.getMessage("categrp.create.retry",  locale));
      links.add("<button type='button' onclick=\"history.back();\">"+messages.getMessage("categrp.button.retry", categrpVO.getName(),  locale)+"</button>");
    }
 
    mav.addObject("msgs", msgs);
    // request.setAttribute("msgs", msgs);
    mav.addObject("links", links);
    
    mav.setViewName("/categrp/message"); // /categrp/message.jsp
    
    return mav;
  }
 
  @RequestMapping(value="/categrp/list.do", method=RequestMethod.GET)
  public ModelAndView list() {
    ModelAndView mav = new ModelAndView();
    
    List<CategrpVO> list = categrpProc.list();
    mav.addObject("list", list);
    mav.setViewName("/categrp/list"); 
    
    return mav;
  }
  
  // ������ �̵��� �ƴ�
  // ���ڿ� ���� 
  // JSON��� for Spring 3.x (4.0���ʹ� RESTful���; Controller�� ���� �ٸ�)
  @ResponseBody 
  @RequestMapping(value="/categrp/update.do", 
                  method=RequestMethod.GET, produces = "text/plain;charset=UTF-8") // JSON, �ѱ۱��� ����
  public String update(int categrpno) {
    System.out.println("-> CategrpCont update(int categrpno) GET called.");
    
    CategrpVO categrpVO = categrpProc.read(categrpno);
    
    JSONObject obj = new JSONObject();
    obj.put("classification", categrpVO.getClassification());
    obj.put("categrpno", categrpVO.getCategrpno());
    obj.put("name", categrpVO.getName());
    obj.put("seqno", categrpVO.getSeqno());
    obj.put("visible", categrpVO.getVisible());
    obj.put("rdate", categrpVO.getRdate());
    
    System.out.println(obj.toJSONString());
    
    return obj.toJSONString();
    // http://localhost:9090/ojt/categrp/update.do?categrpno=1
    // {"categrpno":1,"visible":"Y","seqno":1,"rdate":"2018-05-17 13:01:27","name":"Blog","classification":1}
  }
  
  @RequestMapping(value="/categrp/update.do", method=RequestMethod.POST)
  public ModelAndView update(CategrpVO categrpVO) {
    ModelAndView mav = new ModelAndView();
    
    if(categrpProc.update(categrpVO) == 1){
      mav.setViewName("redirect:/categrp/list.do"); // redirect
      
    } else {
      ArrayList<String> msgs = new ArrayList<String>();
      ArrayList<String> links = new ArrayList<String>(); 
      
      msgs.add("ī�װ��� �׷� ������ �����߽��ϴ�.");
      msgs.add("�˼������� �ٽ� �ѹ� �õ��� �ּ���. ���� ����: ��000-0000-0000");
      mav.addObject("msgs", msgs);

      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do';\">���</button>");
      mav.addObject("links", links);
      
      mav.setViewName("/categrp/message");
    }
    return mav;
  }
  
  @ResponseBody
  @RequestMapping(value = "/categrp/delete.do", 
                  method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
  public String delete_form(int categrpno, Locale locale) {
    System.out.println("--> delete_form() GET executed");
 
    int count = categoryProc.countByCategrpno(categrpno);
 
    JSONObject obj = new JSONObject();
    obj.put("count", count);
 
    return obj.toJSONString();
  }
  
  
  /**
   * ���� ó��
   * @param categrpVO
   * @return
   */
  @RequestMapping(value="/categrp/delete.do", method=RequestMethod.POST)
  public ModelAndView delete(int categrpno, Locale locale) {
    ModelAndView mav = new ModelAndView();
    
    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>();
    
    // ���� �����Ǵ� �׷����� �о��.
    CategrpVO categrpVO = categrpProc.read(categrpno);
    
    // �ڽ� ���̺� ���ڵ� ���� ����
    int category_count = categoryProc.deleteByCategrpno(categrpno);
    
    if (category_count > 0) {
      msgs.add(messages.getMessage("categrp.delete.count", categrpVO.getName()+"/"+category_count, locale));
    }
    
    // ī�װ��� �׷� ����
    if (categrpProc.delete(categrpno) == 1) {
      // mav.setViewName("redirect:/categrp/list.do");
 
      msgs.add(messages.getMessage("categrp.delete.success", categrpVO.getName(), locale));
 
      links.add("<button type='button' onclick=\"location.href='./list.do'\">���</button>");
    } else {
      msgs.add(messages.getMessage("categrp.delete.fail", categrpVO.getName(), locale));
      msgs.add(messages.getMessage("categrp.delete.retry", locale));
      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do'\">���</button>");
    }
 
    mav.addObject("msgs", msgs);
    mav.addObject("links", links);
    
    mav.setViewName("/categrp/message"); // /categrp/message.jsp
    
    return mav;
  }
  
  @RequestMapping(value="/categrp/update_seqno_up.do", method=RequestMethod.POST)
  public ModelAndView update_seqno_up(int categrpno) {
    ModelAndView mav = new ModelAndView();
    
    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>(); 
    
    if(categrpProc.update_seqno_up(categrpno) == 1){
      mav.setViewName("redirect:/categrp/list.do"); // redirect
      
    } else {
      msgs.add("ī�װ��� �׷� �켱 ���� �ø��⿡ �����߽��ϴ�.");
      msgs.add("�˼������� �ٽ� �ѹ� �õ��� �ּ���. ���� ����: ��000-0000-0000");
      mav.addObject("msgs", msgs);

      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do';\">���</button>");
      mav.addObject("links", links);
      
      mav.setViewName("/categrp/message");
    }
    return mav;
  }
  
  @RequestMapping(value="/categrp/update_seqno_down.do", method=RequestMethod.POST)
  public ModelAndView update_seqno_down(int categrpno) {
    ModelAndView mav = new ModelAndView();
    
    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>(); 
    
    if(categrpProc.update_seqno_down(categrpno) == 1){
      mav.setViewName("redirect:/categrp/list.do"); // redirect
      
    } else {
      msgs.add("ī�װ��� �׷� �켱 ���� �����⿡ �����߽��ϴ�.");
      msgs.add("�˼������� �ٽ� �ѹ� �õ��� �ּ���. ���� ����: ��000-0000-0000");
      mav.addObject("msgs", msgs);
      
      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do';\">���</button>");
      mav.addObject("links", links);
      
      mav.setViewName("/categrp/message");
    }
    return mav;
  }
  
  
  
}
