package dev.mvc.category;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.categrp.CategrpProcInter;
import dev.mvc.categrp.CategrpVO;

@Controller
public class CategoryCont {
  @Autowired // DI: FK ���̺��� ��ü ���� ����
  @Qualifier("dev.mvc.categrp.CategrpProc")
  private CategrpProcInter categrpProc;
  
  @Autowired
  @Qualifier("dev.mvc.category.CategoryProc")
  private CategoryProcInter categoryProc = null;
  
  public CategoryCont() {
    System.out.println("-> CategoryCont created.");
  }
  
  // ��� ��
  @RequestMapping(value = "/category/create.do", method = RequestMethod.GET)
  public ModelAndView create(int categrpno) { // *** �⺻������ categrp�� PK�� ������ ��
    ModelAndView mav = new ModelAndView();
    
    // System.out.println("categrpno: " + categrpno);
    
    CategrpVO categrpVO = categrpProc.read(categrpno);
    mav.addObject("categrpVO", categrpVO); // *** ������ ����
    
    mav.setViewName("/category/create");
    
    return mav;
    // http://localhost:9090/ojt/category/create.do
  }
  
  // ��� ó��
  @RequestMapping(value = "/category/create.do", method = RequestMethod.POST)
  public ModelAndView create(CategoryVO categoryVO) {
    ModelAndView mav = new ModelAndView();
    
    int categrpno = categoryVO.getCategrpno();
    // System.out.println("categrpno: " + categrpno);
    
    if (categoryProc.create(categoryVO) == 1) {
      // msgs.add("ī�װ����� ����߽��ϴ�.");
      // �ٷ� ������ �̵� - redirect: Ȯ���ڸ� ���������!!
      mav.setViewName("redirect:/category/list.do?categrpno=" + categrpno); // ***parameter
                                                                            // ������
                                                                            // ��
      
    } else {
      ArrayList<String> msgs = new ArrayList<String>();
      ArrayList<String> links = new ArrayList<String>();
      
      msgs.add("ī�װ��� ��Ͽ� �����߽��ϴ�.");
      msgs.add("�˼������� �ٽ� �ѹ� �õ��� �ּ���. ���� ����: ��000-0000-0000");
      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do';\">���</button>");
      
      mav.addObject("msgs", msgs);
      mav.addObject("links", links);
      mav.setViewName("/category/message");
    }
    return mav;
  }
  
  // ��� ī�װ��� ����Ʈ(list_all.do) ���
  @RequestMapping(value = "/category/list_all.do", method = RequestMethod.GET)
  public ModelAndView list() {
    // System.out.println("--> list() GET called.");
    ModelAndView mav = new ModelAndView();
    
    List<Categrp_CategoryVO> list = categoryProc.list();
    
    mav.addObject("list", list);
    mav.setViewName("/category/list");
    
    return mav;
  }
  
  // ī�װ��� �׷캰 ī�װ��� list ���
  @RequestMapping(value = "/category/list.do", method = RequestMethod.GET)
  public ModelAndView list_by_categrpno(int categrpno) {
    ModelAndView mav = new ModelAndView();
    
    CategrpVO categrpVO = categrpProc.read(categrpno);
    List<Categrp_CategoryVO> list = categoryProc.list_by_categrpno(categrpno);
    
    mav.addObject("categrpVO", categrpVO);
    mav.addObject("list", list);
    mav.setViewName("/category/list");
    
    return mav;
  }
  
  /**
   * <Xmp> ���� �� SELECT categoryno, categrpno, title, seqno, visible, ids, rdate
   * FROM category WHERE categoryno=#{categoryno} </Xmp>
   * 
   * @param categrpno
   * @return
   */
  @ResponseBody
  @RequestMapping(value = "/category/update.do", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
  public String update(int categoryno) {
    // System.out.println("--> update() GET called.");
    
    CategoryVO categoryVO = categoryProc.read(categoryno);
    
    JSONObject obj = new JSONObject();
    obj.put("categoryno", categoryno);
    obj.put("categrpno", categoryVO.getCategrpno());
    obj.put("title", categoryVO.getTitle());
    obj.put("seqno", categoryVO.getSeqno());
    obj.put("visible", categoryVO.getVisible());
    obj.put("ids", categoryVO.getIds());
    obj.put("rdate", categoryVO.getRdate());
    
    return obj.toJSONString();
  }
  
  // ���� ó��
  @RequestMapping(value = "/category/update.do", method = RequestMethod.POST)
  public ModelAndView update(CategoryVO categoryVO) {
    // System.out.println("--> update() POST executed");
    ModelAndView mav = new ModelAndView();
    
    int categrpno = categoryVO.getCategrpno();
    int categoryno = categoryVO.getCategoryno();
    // System.out.println("categrpno: " + categrpno);
    // System.out.println("categoryno: " + categoryno);
    
    int count = categoryProc.update(categoryVO);
    // System.out.println("count: " + count);
    
    if (count == 1) {
      // msgs.add("ī�װ����� �����߽��ϴ�.");
      mav.setViewName("redirect:/category/list.do?categrpno=" + categrpno); // ***parameter
                                                                            // ������
                                                                            // ��
      
    } else {
      ArrayList<String> msgs = new ArrayList<String>();
      ArrayList<String> links = new ArrayList<String>();
      
      msgs.add("ī�װ��� ������ �����߽��ϴ�.");
      msgs.add("�˼������� �ٽ� �ѹ� �õ��� �ּ���. ���� ����: ��000-0000-0000");
      
      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do?categrpno=" + categrpno + "';\">���</button>");
      
      mav.addObject("msgs", msgs);
      mav.addObject("links", links);
      
      mav.setViewName("/category/message");
    }
    return mav;
  }
  
  /**
   * ���� ó��
   * 
   * @param categrpno
   *          ī�װ��� �׷� ��ȣ
   * @param categoryno
   *          ������ ���ڵ� ��ȣ
   * @return
   */
  @RequestMapping(value = "/category/delete.do", method = RequestMethod.POST)
  public ModelAndView delete(int categrpno, int categoryno) {
    ModelAndView mav = new ModelAndView();
    // System.out.println("--> delete() POST executed");
    
    // System.out.println("categrpno: " + categrpno);
    // System.out.println("count: " + count);
    int count = categoryProc.delete(categoryno);
    
    if (count == 1) {
      // msgs.add("ī�װ����� �����߽��ϴ�.");
      mav.setViewName("redirect:/category/list.do?categrpno=" + categrpno); // ***parameter
                                                                            // ������
                                                                            // ��
      
    } else {
      ArrayList<String> msgs = new ArrayList<String>();
      ArrayList<String> links = new ArrayList<String>();
      
      msgs.add("ī�װ��� ������ �����߽��ϴ�.");
      msgs.add("�˼������� �ٽ� �ѹ� �õ��� �ּ���. ���� ����: ��000-0000-0000");
      
      links.add("<button type='button' onclick=\"history.back();\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do?categrpno=" + categrpno + "';\">���</button>");
      
      mav.addObject("msgs", msgs);
      mav.addObject("links", links);
      mav.setViewName("/category/message");
    }
    
    return mav;
  }
  
  // ī�װ��� �켱 ���� �ø���
  @RequestMapping(value = "/category/update_seqno_up.do", method = RequestMethod.POST)
  public ModelAndView update_seqno_up(int categrpno, int categoryno) {
    ModelAndView mav = new ModelAndView();
    
    int count = categoryProc.update_seqno_up(categoryno);
    // System.out.println("count: " + count);
    
    if (count == 1) {
      mav.setViewName("redirect:/category/list.do?categrpno=" + categrpno); // redirect
    }
    
    return mav;
  }
  
  // ī�װ��� �켱 ���� ������
  @RequestMapping(value = "/category/update_seqno_down.do", method = RequestMethod.POST)
  public ModelAndView update_seqno_down(int categrpno, int categoryno) {
    ModelAndView mav = new ModelAndView();
    
    int count = categoryProc.update_seqno_down(categoryno);
    // System.out.println("count: " + count);
    
    if (count == 1) {
      mav.setViewName("redirect:/category/list.do?categrpno=" + categrpno); // redirect
    }
    
    return mav;
  }
  
}
