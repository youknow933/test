package dev.mvc.category;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("dev.mvc.category.CategoryDAO")
public class CategoryDAO implements CategoryDAOInter {
  
  @Autowired
  private SqlSessionTemplate sqlSessionTemplate = null;
  
  public CategoryDAO() {
    System.out.println("--> CategoryDAO created.");
  }
  
  @Override
  public int create(CategoryVO categoryVO) {
    int count = sqlSessionTemplate.insert("category.create", categoryVO);
    return count;
  }
  
  @Override
  public List<Categrp_CategoryVO> list() {
    List<Categrp_CategoryVO> list = sqlSessionTemplate.selectList("category.list");
    return list;
  }
  
  @Override
  public List<Categrp_CategoryVO> list_by_categrpno(int categrpno) {
    List<Categrp_CategoryVO> list = sqlSessionTemplate.selectList("category.list_by_categrpno", categrpno); // parameter��
    return list;
  }
  
  @Override
  public CategoryVO read(int categoryno) {
    CategoryVO categoryVO = sqlSessionTemplate.selectOne("category.read", categoryno);
    return categoryVO;
  }
  
  @Override
  public int update(CategoryVO categoryVO) {
    return sqlSessionTemplate.update("category.update", categoryVO);
  }
  
  @Override
  public int delete(int categoryno) {
    return sqlSessionTemplate.delete("category.delete", categoryno);
  }
  
  @Override
  public int update_seqno_up(int categoryno) {
    return sqlSessionTemplate.update("category.update_seqno_up", categoryno); // namespace
                                                                              // ���̱�
  }
  
  @Override
  public int update_seqno_down(int categoryno) {
    return sqlSessionTemplate.update("category.update_seqno_down", categoryno);
  }
  
  @Override
  public int countByCategrpno(int categrpno) {
    return sqlSessionTemplate.selectOne("category.countByCategrpno", categrpno);
  }
  
  @Override
  public int deleteByCategrpno(int categrpno) {
    return sqlSessionTemplate.delete("category.deleteByCategrpno", categrpno);
  }
  
  // 5/25
  @Override
  public int increaseCnt(int categoryno) {
    return sqlSessionTemplate.update("category.increaseCnt", categoryno);
  }
  
  @Override
  public int decreaseCnt(int categoryno) {
    return sqlSessionTemplate.update("category.decreaseCnt", categoryno);
  }
  
}