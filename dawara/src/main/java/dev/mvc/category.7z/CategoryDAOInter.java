package dev.mvc.category;

import java.util.List;
 
public interface CategoryDAOInter {
  
  /**
   * <Xmp>
   *   <insert id="create" parameterType="CategoryVO">
   * <Xmp>
   * </Xmp>
   * @param categoryVO
   * @return
   */
  public int create(CategoryVO categoryVO);
  
  /**
   * <Xmp>
   *  <select id="list" resultType="Categrp_CategoryVO">
   * </Xmp>
   * @return
   */
  public List<Categrp_CategoryVO> list();
  
  /**
   * <Xmp>
   *  <select id="list_by_categrpno" resultType="Categrp_CategoryVO" parameterType="int">
   * </Xmp>
   * @return
   */
  public List<Categrp_CategoryVO> list_by_categrpno(int categrpno);
  
  /**
   * <Xmp>
   *  <select id="read" resultType="CategoryVO" parameterType="int">
   * </Xmp>
   * @return
   */
  public CategoryVO read(int categoryno);
  
  /**
   * <Xmp>
   *  <update id="update" parameterType="categoryVO">
   * </Xmp>
   * @return
   */
  public int update(CategoryVO categoryVO);
  
  /**
   * <Xmp>
   *   DELETE FROM category WHERE categoryno = #{categoryno}
   * </Xmp>
   * @param categoryno
   * @return
   */
  public int delete(int categoryno);
  
  //<update id="update_seqno_up" parameterType="int">
  public int update_seqno_up(int categoryno);
   
  // <update id="update_seqno_down" parameterType="int">
  public int update_seqno_down(int categoryno);
  
  //<select id="countByCategrpno" resultType="int" parameterType="int">
  public int countByCategrpno(int categrpno);
  
  //<delete id="deleteByCategrpno" parameterType="int">
  public int deleteByCategrpno(int categrpno);
  
  /**
   * �� �� ����
   * <xmp>
   * <update id="increaseCnt" parameterType="int">
   * </xmp> 
   * @param categoryno
   * @return
   */
  public int increaseCnt(int categoryno);
  
  /**
   * �� �� ����
   * <xmp>
   * <update id="decreaseCnt" parameterType="int">
   * </xmp> 
   * @param categoryno
   * @return
   */
  public int decreaseCnt(int categoryno);
}