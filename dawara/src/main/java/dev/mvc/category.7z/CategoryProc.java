package dev.mvc.category;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
 
@Component("dev.mvc.category.CategoryProc")
public class CategoryProc implements CategoryProcInter {
  
  @Autowired
  @Qualifier("dev.mvc.category.CategoryDAO")
  private CategoryDAOInter categoryDAO = null;
  
  public CategoryProc() {
    System.out.println("--> CategoryProc created.");
  }

  @Override
  public int create(CategoryVO categoryVO) {
    int count = categoryDAO.create(categoryVO);
    return count;
  }

  @Override
  public List<Categrp_CategoryVO> list() {
    List<Categrp_CategoryVO> list = categoryDAO.list();
    return list;
  }

  @Override
  public List<Categrp_CategoryVO> list_by_categrpno(int categrpno) {
    List<Categrp_CategoryVO> list = categoryDAO.list_by_categrpno(categrpno);
    return list;
  }

  @Override
  public CategoryVO read(int categoryno) {
    return categoryDAO.read(categoryno);
  }

  @Override
  public int update(CategoryVO categoryVO) {
    return categoryDAO.update(categoryVO);
  }

  @Override
  public int delete(int categoryno) {
    return categoryDAO.delete(categoryno);
  }

  @Override
  public int update_seqno_up(int categoryno) {
    return categoryDAO.update_seqno_up(categoryno);
  }

  @Override
  public int update_seqno_down(int categoryno) {
    return categoryDAO.update_seqno_down(categoryno);
  }

  @Override
  public int countByCategrpno(int categrpno) {
    return categoryDAO.countByCategrpno(categrpno);
  }

  @Override
  public int deleteByCategrpno(int categrpno) {
    return categoryDAO.deleteByCategrpno(categrpno);
  }

  @Override
  public int increaseCnt(int categoryno) {
    int count = categoryDAO.increaseCnt(categoryno);
    
    return count;
  }
  @Override
  public int decreaseCnt(int categoryno) {
    int count = categoryDAO.decreaseCnt(categoryno);
    
    return count;
  }
  
}